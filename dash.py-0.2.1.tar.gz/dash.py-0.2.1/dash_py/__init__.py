"""
Create python docs for dash easily.
"""

__version__ = '0.2.1'
__author__ = 'whtsky'
__license__ = 'MIT'
