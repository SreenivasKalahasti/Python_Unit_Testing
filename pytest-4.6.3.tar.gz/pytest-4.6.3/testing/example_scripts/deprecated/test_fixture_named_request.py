# -*- coding: utf-8 -*-
import pytest


@pytest.fixture
def request():
    pass


def test():
    pass
