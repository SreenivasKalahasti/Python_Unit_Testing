# -*- coding: utf-8 -*-
def test_foo():
    pass
