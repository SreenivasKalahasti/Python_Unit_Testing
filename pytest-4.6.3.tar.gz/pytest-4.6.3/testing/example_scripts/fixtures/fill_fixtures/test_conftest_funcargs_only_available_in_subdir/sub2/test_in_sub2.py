# -*- coding: utf-8 -*-
def test_2(arg2):
    pass
