.. _contributing:

.. include:: ../../CONTRIBUTING.rst
