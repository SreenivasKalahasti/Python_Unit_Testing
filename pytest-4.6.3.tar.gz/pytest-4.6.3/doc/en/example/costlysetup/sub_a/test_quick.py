# -*- coding: utf-8 -*-
def test_quick(setup):
    pass
