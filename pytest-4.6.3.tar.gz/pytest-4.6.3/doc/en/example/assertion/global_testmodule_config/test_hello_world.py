# -*- coding: utf-8 -*-
hello = "world"


def test_func():
    pass
