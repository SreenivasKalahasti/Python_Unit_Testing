.. _linear_examples:

Generalized Linear Models
-------------------------

Examples concerning the :mod:`sklearn.linear_model` module.
