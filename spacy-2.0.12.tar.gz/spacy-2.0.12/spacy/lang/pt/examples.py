# coding: utf8
from __future__ import unicode_literals


"""
Example sentences to test spaCy and its language models.

>>> from spacy.lang.pt.examples import sentences
>>> docs = nlp.pipe(sentences)
"""


sentences = [
    "Apple está querendo comprar uma startup do Reino Unido por 100 milhões de dólares",
    "Carros autônomos empurram a responsabilidade do seguro para os fabricantes."
    "São Francisco considera banir os robôs de entrega que andam pelas calçadas",
    "Londres é a maior cidade do Reino Unido"
]
