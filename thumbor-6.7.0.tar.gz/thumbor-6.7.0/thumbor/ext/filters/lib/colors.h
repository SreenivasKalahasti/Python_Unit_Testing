#ifndef __COLORS__H__
#define __COLORS__H__

void rgb2ycbcr(float *r, float *g, float *b);
void ycbcr2rgb(float *y, float *cb, float *cr);

#endif
