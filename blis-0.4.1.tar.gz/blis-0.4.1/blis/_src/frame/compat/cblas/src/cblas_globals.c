#include "blis.h"
#ifdef BLIS_ENABLE_CBLAS
int CBLAS_CallFromC=0;
int RowMajorStrg=0;
#endif
