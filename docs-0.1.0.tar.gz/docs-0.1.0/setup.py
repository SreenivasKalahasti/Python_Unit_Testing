import setuptools


setuptools.setup(
    name='docs',
    version='0.1.0',
    description='Turn your Python script into a report with inline figures.',
    url='http://github.com/danijar/docs',
    install_requires=[],
    packages=setuptools.find_packages(),
    classifiers=[
        'Programming Language :: Python :: 3',
    ],
)
