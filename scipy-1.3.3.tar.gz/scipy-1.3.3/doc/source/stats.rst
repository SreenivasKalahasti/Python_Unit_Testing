.. automodule:: scipy.stats
   :no-members:
   :no-inherited-members:
   :no-special-members:

.. toctree::
   :hidden:

   stats.mstats
