.. include:: ../release/1.3.1-notes.rst
