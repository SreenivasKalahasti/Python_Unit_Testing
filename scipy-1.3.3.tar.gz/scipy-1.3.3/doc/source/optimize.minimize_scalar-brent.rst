.. _optimize.minimize_scalar-brent:

minimize_scalar(method='brent')
----------------------------------------------

.. scipy-optimize:function:: scipy.optimize.minimize_scalar
   :impl: scipy.optimize.optimize._minimize_scalar_brent
   :method: brent
