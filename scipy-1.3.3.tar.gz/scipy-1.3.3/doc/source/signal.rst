.. automodule:: scipy.signal
   :no-members:
   :no-inherited-members:
   :no-special-members:
