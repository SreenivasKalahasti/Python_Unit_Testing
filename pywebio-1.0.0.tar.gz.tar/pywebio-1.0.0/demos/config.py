# demos 模块的部署地址
demo_host = 'http://pywebio-demos.demo.wangweimin.site'

# https://github.com/wang0618/pywebio-chart-gallery 的部署地址
charts_demo_host = 'http://pywebio-charts.demo.wangweimin.site'
