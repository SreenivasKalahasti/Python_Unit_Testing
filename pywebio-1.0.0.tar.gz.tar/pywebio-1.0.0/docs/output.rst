``pywebio.output`` --- Make output to web browser
====================================================

.. automodule:: pywebio.output
