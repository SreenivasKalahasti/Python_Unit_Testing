Demos
==========

基本demo
------------
使用PyWebIO编写的示例应用

.. automodule:: demos

数据可视化demo
-----------------
PyWebIO支持使用第三方库进行数据可视化，详情见 :ref:`使用PyWebIO进行数据可视化 <visualization>`