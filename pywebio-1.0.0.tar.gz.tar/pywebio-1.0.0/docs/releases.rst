Release notes
=============

.. toctree::
   :maxdepth: 2

   releases/v1.0.0
   releases/v0.3.0
   releases/v0.2.0
