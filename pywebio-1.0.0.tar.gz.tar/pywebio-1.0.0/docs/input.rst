``pywebio.input`` --- Get input from web browser
====================================================

.. automodule:: pywebio.input
   :members:


