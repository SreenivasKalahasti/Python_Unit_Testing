Architecture
================

概念
------------

`Session` 表示浏览器与程序交互产生的一次会话。PyWebIO在会话中运行 ``Task`` ，任务是

