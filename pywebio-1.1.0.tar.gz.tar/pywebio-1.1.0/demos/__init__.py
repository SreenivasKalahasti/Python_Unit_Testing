r"""
.. automodule:: demos.bmi
.. automodule:: demos.input_usage
.. automodule:: demos.output_usage
.. automodule:: demos.chat_room
"""