from .conllu2json import conllu2json
