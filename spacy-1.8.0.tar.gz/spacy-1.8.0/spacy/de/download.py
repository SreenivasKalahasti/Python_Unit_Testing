from ..deprecated import ModelDownload as download


if __name__ == '__main__':
    download.de()
