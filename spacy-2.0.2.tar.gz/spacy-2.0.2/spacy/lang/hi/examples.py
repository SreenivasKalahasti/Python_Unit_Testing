  # coding: utf8
from __future__ import unicode_literals


"""
Example sentences to test spaCy and its language models.

>>> from spacy.lang.hi.examples import sentences
>>> docs = nlp.pipe(sentences)
"""


sentences = [
     "एप्पल 1 अरब डॉलर के लिए यू.के. स्टार्टअप खरीदने पर विचार कर रहा है",
     "स्वायत्त कार निर्माताओं की ओर बीमा दायित्व रखती है",
     "सैन फ्रांसिस्को फुटवे डिलीवरी रोबोटों पर प्रतिबंध लगाने का विचार कर रहा है",
     "लंदन यूनाइटेड किंगडम का बड़ा शहर है।",
     "आप कहाँ हैं?",
     "फ्रांस के राष्ट्रपति कौन हैं?",
     "संयुक्त राज्य की राजधानी क्या है?",
     "बराक ओबामा का जन्म हुआ था?"
]
