# coding: utf8
from __future__ import unicode_literals


"""
Example sentences to test spaCy and its language models.

>>> from spacy.lang.zh.examples import sentences
>>> docs = nlp.pipe(sentences)
"""


sentences = [
    "蘋果公司正考量用一億元買下英國的新創公司",
    "自駕車將保險責任歸屬轉移至製造商",
    "舊金山考慮禁止送貨機器人在人行道上行駛",
    "倫敦是英國的大城市"
]
