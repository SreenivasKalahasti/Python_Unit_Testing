.. _using-git:

Working with *NumPy* source code
================================

Contents:

.. toctree::
   :maxdepth: 2

   git_intro
   following_latest
   git_development
   git_resources
