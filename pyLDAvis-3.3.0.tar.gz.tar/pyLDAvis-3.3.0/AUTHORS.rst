=======
Credits
=======

Development Lead
----------------

* Ben Mabey <ben@benmabey.com>

Contributors
------------

* Paul English <paul@onfrst.com> - JS and CSS fixes and improvements.
* Mark Susol <marksusol@gmail.com> - Python and JSS improvements.
