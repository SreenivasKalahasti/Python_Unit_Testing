# coding: utf8
from __future__ import unicode_literals

from ._classes.convolution import ExtractWindow  # noqa: F401
