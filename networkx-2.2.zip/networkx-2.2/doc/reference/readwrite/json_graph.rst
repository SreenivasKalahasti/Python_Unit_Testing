JSON
====
.. automodule:: networkx.readwrite.json_graph
.. autosummary::
   :toctree: generated/

   node_link_data
   node_link_graph
   adjacency_data
   adjacency_graph
   cytoscape_data
   cytoscape_graph
   tree_data
   tree_graph
   jit_data
   jit_graph
