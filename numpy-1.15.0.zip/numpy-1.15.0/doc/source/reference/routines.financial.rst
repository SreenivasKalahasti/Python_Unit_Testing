Financial functions
*******************

.. currentmodule:: numpy

Simple financial functions
--------------------------

.. autosummary::
   :toctree: generated/

   fv
   pv
   npv
   pmt
   ppmt
   ipmt
   irr
   mirr
   nper
   rate
